import Main from './Main'
import Two from './Two'

import './App.css';

import {
  Route,
  Link,
  Switch,
  Redirect
} from 'react-router-dom';

function App() {
  return (
    <div className="App">
      <div className='header'>
        <img src='https://icons.iconarchive.com/icons/martz90/circle/48/camera-icon.png' className='logo'></img>
      <ul className='menu'>
        
    <li><Link to="/" >Main</Link></li>
    <li><Link to="/two" >Next</Link></li>
      </ul>
      </div>
      <Switch>
        <Route exact path="/" component={Main}/>
        <Route path="/two" component={Two}/>
        <Redirect to="/"/>
      </Switch>
    </div>
  );
}

export default App;
