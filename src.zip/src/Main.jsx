import React from 'react'

const Main = () => {
  return (
    <div  className='app'>
        <img className='backgrounde' scr = "https://w-dog.ru/wallpapers/13/5/547494496845953/kosmos-zvezdy-planeta.jpg"></img>
        
    </div>
  )
}

export default Main